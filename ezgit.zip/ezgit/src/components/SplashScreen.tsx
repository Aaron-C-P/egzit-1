import { useState, useEffect } from 'react';
import { Truck } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

// Unsplash motion-themed images (free to use with attribution)
const motionImages = [
  {
    url: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=1200&q=80',
    photographer: 'Hanson Lu',
    photographerUrl: 'https://unsplash.com/@hansonluu',
  },
  {
    url: 'https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?w=1200&q=80',
    photographer: 'Samuele Errico Piccarini',
    photographerUrl: 'https://unsplash.com/@samuele_errico_piccarini',
  },
  {
    url: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1200&q=80',
    photographer: 'Bruno van der Kraan',
    photographerUrl: 'https://unsplash.com/@brunovdkraan',
  },
  {
    url: 'https://images.unsplash.com/photo-1605732562742-3023a888e56e?w=1200&q=80',
    photographer: 'Chris Liverani',
    photographerUrl: 'https://unsplash.com/@chrisliverani',
  },
];

const appHighlights = [
  '🚚 AI-powered inventory management with QR tracking',
  '📍 Jamaica-wide address search with street-level accuracy',
  '🔍 Connect with verified moving companies',
  '🗺️ Real-time route optimization and tracking',
  '💳 Secure booking and payment system',
];

const SPLASH_SESSION_KEY = 'egzit_splash_shown';

export function checkSplashShown(): boolean {
  try {
    return sessionStorage.getItem(SPLASH_SESSION_KEY) === 'true';
  } catch {
    return false;
  }
}

export function markSplashShown(): void {
  try {
    sessionStorage.setItem(SPLASH_SESSION_KEY, 'true');
  } catch {
    // Ignore storage errors
  }
}

export default function SplashScreen({ onComplete }: SplashScreenProps) {
  const [currentImage, setCurrentImage] = useState(0);
  const [progress, setProgress] = useState(0);
  const [truckPosition, setTruckPosition] = useState(0);
  const [imageError, setImageError] = useState(false);

  // Preload images
  useEffect(() => {
    motionImages.forEach((img) => {
      const image = new Image();
      image.onerror = () => setImageError(true);
      image.src = img.url;
    });
  }, []);

  useEffect(() => {
    // Animate progress bar over 5 seconds
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        return prev + 1;
      });
    }, 50);

    // Animate truck position
    const truckInterval = setInterval(() => {
      setTruckPosition(prev => {
        if (prev >= 100) return 0;
        return prev + 2;
      });
    }, 50);

    // Change images every 1.25 seconds
    const imageInterval = setInterval(() => {
      setCurrentImage(prev => (prev + 1) % motionImages.length);
    }, 1250);

    // Complete after 5 seconds
    const timer = setTimeout(() => {
      markSplashShown();
      onComplete();
    }, 5000);

    return () => {
      clearInterval(progressInterval);
      clearInterval(truckInterval);
      clearInterval(imageInterval);
      clearTimeout(timer);
    };
  }, [onComplete]);

  const handleSkip = () => {
    markSplashShown();
    onComplete();
  };

  const currentImageData = motionImages[currentImage];

  return (
    <div className="fixed inset-0 z-[100] overflow-hidden">
      {/* Background Images with Smooth Transition */}
      <div className="absolute inset-0">
        {motionImages.map((img, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-700 ease-in-out ${
              index === currentImage ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <img
              src={img.url}
              alt={`Motion ${index + 1}`}
              className="w-full h-full object-cover"
              loading={index === 0 ? 'eager' : 'lazy'}
            />
          </div>
        ))}
        
        {/* Red Gradient Overlay - 70% coverage */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#FF0000]/80 via-[#CC0000]/70 to-[#990000]/80" />
        
        {/* White Gradient Accent - 30% */}
        <div className="absolute inset-0 bg-gradient-to-t from-white/5 via-transparent to-white/20" />
        
        {/* Animated particles */}
        <div className="absolute inset-0 overflow-hidden">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-white/20 rounded-full animate-pulse"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${2 + Math.random() * 2}s`,
              }}
            />
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 h-full flex flex-col items-center justify-center px-6 py-12">
        {/* Logo Section */}
        <div className="text-center mb-6 animate-fade-in">
          <div className="w-24 h-24 rounded-3xl bg-white flex items-center justify-center mx-auto mb-4 shadow-2xl">
            <span 
              className="text-5xl font-black"
              style={{ 
                color: '#FF0000',
                textShadow: '2px 2px 0 #CC0000'
              }}
            >
              E
            </span>
          </div>
          <h1 
            className="text-5xl md:text-6xl font-black tracking-tight"
            style={{ 
              color: 'white',
              textShadow: '3px 3px 0 #CC0000, -1px -1px 0 #FF0000'
            }}
          >
            EGZIT
          </h1>
          <p 
            className="text-lg md:text-xl font-medium mt-2"
            style={{ 
              color: 'white',
              textShadow: '1px 1px 2px rgba(0,0,0,0.5)'
            }}
          >
            AI-Powered Smart Moving Assistant
          </p>
        </div>

        {/* App Description */}
        <div 
          className="max-w-lg text-center mb-6 px-4 animate-fade-in"
          style={{ animationDelay: '0.3s' }}
        >
          <p 
            className="text-sm md:text-base leading-relaxed"
            style={{ 
              color: 'white',
              textShadow: '1px 1px 3px rgba(153,0,0,0.8)'
            }}
          >
            Transform your moving experience with EGZIT - Jamaica&apos;s premier AI-powered relocation platform. 
            From smart inventory management to verified mover connections, we make your move seamless, 
            organized, and stress-free.
          </p>
        </div>

        {/* Key Highlights */}
        <div 
          className="max-w-md w-full mb-6 px-4 animate-fade-in"
          style={{ animationDelay: '0.5s' }}
        >
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 border border-white/20">
            <ul className="space-y-2">
              {appHighlights.map((highlight, index) => (
                <li 
                  key={index}
                  className="text-sm md:text-base flex items-start gap-2"
                  style={{ 
                    color: 'white',
                    textShadow: '1px 1px 2px rgba(153,0,0,0.7)'
                  }}
                >
                  <span className="shrink-0">{highlight}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Moving Truck Animation */}
        <div className="w-full max-w-md mb-4 px-4">
          <div className="relative h-16 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 overflow-hidden">
            {/* Road markings */}
            <div className="absolute bottom-2 left-0 right-0 h-1 flex gap-4 px-4">
              {[...Array(12)].map((_, i) => (
                <div key={i} className="w-6 h-1 bg-white/40 rounded" />
              ))}
            </div>
            
            {/* Moving Truck */}
            <div 
              className="absolute top-1/2 -translate-y-1/2 transition-all duration-100 ease-linear"
              style={{ left: `${truckPosition}%`, transform: `translateX(-50%) translateY(-50%)` }}
            >
              <div className="relative">
                {/* Truck body */}
                <div className="flex items-end">
                  {/* Cargo */}
                  <div className="w-10 h-8 bg-white rounded-t-lg rounded-bl-lg shadow-lg flex items-center justify-center">
                    <span className="text-xs font-bold text-[#FF0000]">EGZIT</span>
                  </div>
                  {/* Cab */}
                  <div className="w-6 h-6 bg-white rounded-t-lg rounded-br-lg -ml-1 shadow-lg relative">
                    <div className="absolute top-1 right-1 w-3 h-2 bg-[#87CEEB] rounded-sm" />
                  </div>
                </div>
                {/* Wheels */}
                <div className="flex justify-between px-1 -mt-1">
                  <div className="w-3 h-3 bg-gray-800 rounded-full border-2 border-white animate-spin" style={{ animationDuration: '0.3s' }} />
                  <div className="w-3 h-3 bg-gray-800 rounded-full border-2 border-white animate-spin" style={{ animationDuration: '0.3s' }} />
                  <div className="w-3 h-3 bg-gray-800 rounded-full border-2 border-white animate-spin" style={{ animationDuration: '0.3s' }} />
                </div>
                {/* Exhaust smoke */}
                <div className="absolute -left-3 top-1/2 flex gap-1">
                  <div className="w-2 h-2 bg-white/40 rounded-full animate-pulse" />
                  <div className="w-1.5 h-1.5 bg-white/30 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }} />
                </div>
              </div>
            </div>

            {/* Destination flag */}
            <div className="absolute right-4 top-1/2 -translate-y-1/2">
              <div className="flex flex-col items-center">
                <div className="w-0.5 h-6 bg-white" />
                <div className="w-4 h-3 bg-[#FF0000] -mt-3 ml-2 rounded-r-sm animate-pulse" />
              </div>
            </div>
          </div>
        </div>

        {/* Circular Progress Indicator */}
        <div className="relative w-16 h-16 mb-4">
          <svg className="w-full h-full transform -rotate-90">
            {/* Background circle */}
            <circle
              cx="32"
              cy="32"
              r="28"
              stroke="white"
              strokeWidth="4"
              fill="none"
              opacity="0.3"
            />
            {/* Progress circle */}
            <circle
              cx="32"
              cy="32"
              r="28"
              stroke="white"
              strokeWidth="4"
              fill="none"
              strokeLinecap="round"
              strokeDasharray={`${2 * Math.PI * 28}`}
              strokeDashoffset={`${2 * Math.PI * 28 * (1 - progress / 100)}`}
              className="transition-all duration-100 ease-linear"
              style={{ filter: 'drop-shadow(0 0 4px rgba(255,255,255,0.5))' }}
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <Truck 
              className="h-6 w-6 text-white" 
              style={{ filter: 'drop-shadow(1px 1px 2px rgba(153,0,0,0.8))' }}
            />
          </div>
        </div>

        {/* Linear Progress Bar */}
        <div className="w-64 h-2 bg-white/30 rounded-full overflow-hidden mb-4">
          <div 
            className="h-full bg-white rounded-full transition-all duration-100 ease-linear"
            style={{ 
              width: `${progress}%`,
              boxShadow: '0 0 10px rgba(255,255,255,0.5)'
            }}
          />
        </div>

        {/* Loading text */}
        <p 
          className="text-sm mb-4"
          style={{ 
            color: 'white',
            textShadow: '1px 1px 2px rgba(0,0,0,0.3)'
          }}
        >
          Loading your experience... {progress}%
        </p>

        {/* Image Indicators */}
        <div className="flex gap-2 mb-4">
          {motionImages.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentImage(index)}
              className={`w-3 h-3 rounded-full transition-all duration-300 ${
                index === currentImage 
                  ? 'bg-white scale-125' 
                  : 'bg-white/40 hover:bg-white/60'
              }`}
              aria-label={`Go to image ${index + 1}`}
            />
          ))}
        </div>

        {/* Skip Button */}
        <button
          onClick={handleSkip}
          className="text-sm font-medium transition-all duration-200 hover:scale-105 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/20"
          style={{ 
            color: 'white',
            textShadow: '1px 1px 2px rgba(0,0,0,0.3)'
          }}
        >
          Skip intro →
        </button>
      </div>

      {/* Unsplash Attribution */}
      <div className="absolute bottom-4 left-4 z-20">
        <a
          href={currentImageData.photographerUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="text-xs opacity-60 hover:opacity-100 transition-opacity"
          style={{ 
            color: 'white',
            textShadow: '1px 1px 2px rgba(0,0,0,0.5)'
          }}
        >
          Photo by {currentImageData.photographer} on Unsplash
        </a>
      </div>

      {/* Developer Credit - Bottom Right */}
      <div className="absolute bottom-4 right-4 z-20">
        <p 
          className="text-sm font-sans"
          style={{ 
            color: 'white',
            textShadow: '1px 1px 0 #FF0000, -1px -1px 0 #CC0000, 1px -1px 0 #CC0000, -1px 1px 0 #CC0000'
          }}
        >
          Developed by <span className="font-bold">Aaron Prince</span>
        </p>
      </div>

      {/* Error Fallback */}
      {imageError && (
        <div className="absolute inset-0 bg-gradient-to-br from-[#FF0000] to-[#990000] -z-10" />
      )}
    </div>
  );
}
