import { ReactNode } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { BottomNav } from './BottomNav';
import { Home, Package, Sparkles, Truck, User, LogOut, Route, ClipboardList, Settings } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';
import { useUserRole } from '@/hooks/useUserRole';
import { Button } from '@/components/ui/button';

interface AppLayoutProps {
  children: ReactNode;
  hideNav?: boolean;
}

interface SidebarItem {
  icon: React.ElementType;
  label: string;
  path: string;
  adminOnly?: boolean;
}

const sidebarItems: SidebarItem[] = [
  { icon: Home, label: 'Dashboard', path: '/' },
  { icon: Package, label: 'My Items', path: '/inventory' },
  { icon: Sparkles, label: 'Packing Tips', path: '/packing' },
  { icon: Truck, label: 'Find Movers', path: '/movers' },
  { icon: ClipboardList, label: 'My Moves', path: '/my-moves' },
  { icon: Route, label: 'Route Planner', path: '/route' },
  { icon: User, label: 'Profile', path: '/profile' },
  { icon: Settings, label: 'Admin', path: '/admin', adminOnly: true },
];

export function AppLayout({ children, hideNav = false }: AppLayoutProps) {
  const location = useLocation();
  const { signOut } = useAuth();
  const { isAdmin } = useUserRole();

  // Filter items based on admin status
  const visibleItems = sidebarItems.filter(item => !item.adminOnly || isAdmin);

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop Sidebar - Hidden on mobile */}
      <aside className="hidden lg:flex lg:flex-col lg:fixed lg:inset-y-0 lg:left-0 lg:w-64 lg:bg-card lg:border-r lg:border-border lg:z-50">
        {/* Logo */}
        <div className="h-16 flex items-center px-6 border-b border-border">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-lg bg-primary flex items-center justify-center">
              <Truck className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-foreground">EGZIT</span>
          </Link>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {visibleItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200",
                  isActive
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                )}
              >
                <item.icon className="h-5 w-5" />
                <span className="font-medium">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-border">
          <Button
            variant="ghost"
            className="w-full justify-start text-muted-foreground hover:text-destructive"
            onClick={signOut}
          >
            <LogOut className="h-5 w-5 mr-3" />
            Sign Out
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className={cn(
        "lg:ml-64",
        hideNav ? "" : "pb-20 lg:pb-0"
      )}>
        {children}
      </main>

      {/* Mobile Bottom Nav - Hidden on desktop */}
      {!hideNav && (
        <div className="lg:hidden">
          <BottomNav />
        </div>
      )}
    </div>
  );
}
