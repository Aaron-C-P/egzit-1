import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { AppLayout } from '@/components/navigation/AppLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ArrowLeft, Send, Loader2, Truck, User, Shield } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { useUserRole } from '@/hooks/useUserRole';

interface Message {
  id: string;
  content: string;
  sender_id: string;
  sender_type: 'user' | 'mover' | 'admin';
  created_at: string;
}

export default function Chat() {
  const { moverId } = useParams<{ moverId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { isAdmin } = useUserRole();
  const queryClient = useQueryClient();
  const [message, setMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [messages, setMessages] = useState<Message[]>([]);

  // Check if this is a user ID (for admin-user chat) or mover ID
  const isUserId = moverId && moverId.length > 20; // UUIDs are typically longer

  // Fetch mover details (if moverId is a mover)
  const { data: mover } = useQuery({
    queryKey: ['chat-mover', moverId],
    queryFn: async () => {
      if (isUserId) return null;
      const { data, error } = await supabase
        .from('movers')
        .select('*')
        .eq('id', moverId)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: !!moverId && !isUserId,
  });

  // Fetch user details (if admin chatting with user)
  const { data: chatUser } = useQuery({
    queryKey: ['chat-user', moverId],
    queryFn: async () => {
      if (!isUserId || !isAdmin) return null;
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', moverId)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: !!moverId && isUserId && isAdmin,
  });

  // Simulated messages for demo - in production, you'd use a real-time chat table
  useEffect(() => {
    if (mover && user && !isUserId) {
      // Simulate initial messages from mover
      setMessages([
        {
          id: '1',
          content: `Hi! I'm from ${mover.name}. How can I help you with your move?`,
          sender_id: moverId!,
          sender_type: 'mover',
          created_at: new Date(Date.now() - 3600000).toISOString(),
        },
      ]);
    } else if (chatUser && user && isAdmin && isUserId) {
      // Admin chatting with user
      setMessages([
        {
          id: '1',
          content: `Hello ${chatUser.name || 'there'}, I'm here to help with your move request. How can I assist you?`,
          sender_id: user.id,
          sender_type: 'admin',
          created_at: new Date(Date.now() - 3600000).toISOString(),
        },
      ]);
    }
  }, [mover, chatUser, user, moverId, isUserId, isAdmin]);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = () => {
    if (!message.trim() || !user) return;

    const senderType: 'user' | 'admin' = isAdmin && isUserId ? 'admin' : 'user';

    const newMessage: Message = {
      id: Date.now().toString(),
      content: message,
      sender_id: user.id,
      sender_type: senderType,
      created_at: new Date().toISOString(),
    };

    setMessages(prev => [...prev, newMessage]);
    setMessage('');

    // Simulate response after a delay (only for mover chats, not admin-user)
    if (!isUserId && mover) {
    setTimeout(() => {
      const responses = [
        "Thanks for your message! I'll get back to you shortly.",
        "I understand. Let me check our availability for that date.",
        "Great question! Our team is fully equipped to handle that.",
        "I can offer you a competitive quote for your move. Shall I prepare one?",
        "We have availability next week. Would you like to schedule a consultation?",
      ];
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        content: randomResponse,
        sender_id: moverId!,
        sender_type: 'mover',
        created_at: new Date().toISOString(),
      }]);
    }, 1500);
    }
  };

  if ((!mover && !isUserId) || (isUserId && !chatUser && isAdmin)) {
    return (
      <AppLayout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  const chatTitle = isUserId && chatUser 
    ? chatUser.name || chatUser.email || 'User'
    : mover?.name || 'Chat';
  
  const chatSubtitle = isUserId && isAdmin
    ? 'Customer support chat'
    : mover?.response_time || 'Usually responds within 2 hours';

  return (
    <AppLayout hideNav>
      <div className="min-h-screen flex flex-col">
        {/* Header */}
        <div className="bg-card border-b px-4 py-3 sticky top-0 z-10">
          <div className="max-w-3xl mx-auto flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <Avatar className="h-10 w-10">
              {isUserId && isAdmin ? (
                <>
                  <AvatarFallback>
                    <Shield className="h-5 w-5" />
                  </AvatarFallback>
                </>
              ) : (
                <>
                  <AvatarImage src={mover?.logo_url || undefined} />
              <AvatarFallback>
                <Truck className="h-5 w-5" />
              </AvatarFallback>
                </>
              )}
            </Avatar>
            <div className="flex-1">
              <h1 className="font-semibold">{chatTitle}</h1>
              <p className="text-xs text-muted-foreground">
                {chatSubtitle}
              </p>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 max-w-3xl mx-auto w-full">
          {messages.map((msg) => {
            const isUser = msg.sender_type === 'user';
            return (
              <div
                key={msg.id}
                className={`flex gap-3 ${isUser ? 'flex-row-reverse' : ''}`}
              >
                <Avatar className="h-8 w-8 shrink-0">
                  {isUser || msg.sender_type === 'admin' ? (
                    <AvatarFallback>
                      {msg.sender_type === 'admin' ? (
                        <Shield className="h-4 w-4" />
                      ) : (
                        <User className="h-4 w-4" />
                      )}
                    </AvatarFallback>
                  ) : (
                    <>
                      <AvatarImage src={mover?.logo_url || undefined} />
                      <AvatarFallback><Truck className="h-4 w-4" /></AvatarFallback>
                    </>
                  )}
                </Avatar>
                <div className={`max-w-[70%] ${isUser || msg.sender_type === 'admin' ? 'items-end' : 'items-start'}`}>
                  <div
                    className={`rounded-2xl px-4 py-2 ${
                      isUser || msg.sender_type === 'admin'
                        ? msg.sender_type === 'admin'
                          ? 'bg-accent text-accent-foreground rounded-tr-sm'
                          : 'bg-primary text-primary-foreground rounded-tr-sm'
                        : 'bg-muted rounded-tl-sm'
                    }`}
                  >
                    <p className="text-sm">{msg.content}</p>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1 px-1">
                    {format(new Date(msg.created_at), 'h:mm a')}
                  </p>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="border-t bg-card px-4 py-3 sticky bottom-0">
          <div className="max-w-3xl mx-auto flex gap-2">
            <Input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type a message..."
              className="flex-1"
              onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
            />
            <Button onClick={sendMessage} disabled={!message.trim()}>
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
