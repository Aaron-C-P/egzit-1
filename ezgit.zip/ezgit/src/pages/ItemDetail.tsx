import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { ArrowLeft, Package, MapPin, Weight, Printer, Trash2, Edit, CheckCircle2 } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { Tables } from '@/integrations/supabase/types';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { EditItemDialog } from '@/components/inventory/EditItemDialog';
import { AppLayout } from '@/components/navigation/AppLayout';

type Item = Tables<'items'>;

export default function ItemDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [item, setItem] = useState<Item | null>(null);
  const [loading, setLoading] = useState(true);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  useEffect(() => {
    if (id) {
      fetchItem();
    }
  }, [id]);

  const fetchItem = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('items')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      setItem(data);
    } catch (error) {
      console.error('Error fetching item:', error);
      toast.error('Failed to load item details');
      navigate('/inventory');
    } finally {
      setLoading(false);
    }
  };

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const qrCodeElement = document.getElementById('qr-code-print');
    if (!qrCodeElement) return;

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>QR Code - ${item?.name}</title>
          <style>
            body { 
              display: flex; 
              flex-direction: column;
              align-items: center; 
              justify-content: center; 
              height: 100vh; 
              margin: 0;
              font-family: Arial, sans-serif;
            }
            .qr-container {
              text-align: center;
              padding: 20px;
              border: 2px solid #000;
            }
            h2 { margin: 0 0 20px 0; }
            svg { margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="qr-container">
            <h2>${item?.name}</h2>
            ${qrCodeElement.innerHTML}
            <p style="margin-top: 20px;">${item?.qr_code}</p>
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  const handleDelete = async () => {
    if (!item || !confirm('Are you sure you want to delete this item?')) return;

    try {
      const { error } = await supabase
        .from('items')
        .delete()
        .eq('id', item.id);

      if (error) throw error;

      toast.success('Item deleted successfully');
      navigate('/inventory');
    } catch (error) {
      console.error('Error deleting item:', error);
      toast.error('Failed to delete item');
    }
  };

  const togglePacked = async () => {
    if (!item) return;

    try {
      const { error } = await supabase
        .from('items')
        .update({ packed: !item.packed })
        .eq('id', item.id);

      if (error) throw error;

      setItem({ ...item, packed: !item.packed });
      toast.success(item.packed ? 'Marked as unpacked' : 'Marked as packed');
    } catch (error) {
      console.error('Error updating item:', error);
      toast.error('Failed to update item');
    }
  };

  if (loading) {
    return (
      <AppLayout>
        <div className="flex min-h-screen items-center justify-center">
          <div className="text-lg text-muted-foreground">Loading item details...</div>
        </div>
      </AppLayout>
    );
  }

  if (!item) {
    return null;
  }

  const notes = (item.meta as Record<string, unknown> | null)?.['notes'] as string | undefined;

  return (
    <AppLayout>
      <div className="min-h-screen">
        {/* Header */}
        <div className="bg-card border-b px-4 pt-4 pb-3 sticky top-0 z-10">
          <div className="max-w-lg mx-auto flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate('/inventory')}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div className="flex-1 min-w-0">
              <h1 className="text-xl font-bold truncate">{item.name}</h1>
              {item.category && (
                <p className="text-sm text-muted-foreground">{item.category}</p>
              )}
            </div>
            {item.packed && (
              <Badge className="bg-accent text-accent-foreground shrink-0">
                <CheckCircle2 className="h-3 w-3 mr-1" />
                Packed
              </Badge>
            )}
          </div>
        </div>

        <div className="px-4 py-4 max-w-lg mx-auto space-y-4">
          {/* Image */}
          {item.image_url && (
            <Card className="overflow-hidden shadow-soft animate-fade-in">
              <CardContent className="p-0">
                <img
                  src={item.image_url}
                  alt={item.name}
                  className="w-full h-64 object-cover"
                />
              </CardContent>
            </Card>
          )}

          {/* Details */}
          <Card className="shadow-soft animate-fade-in" style={{ animationDelay: '50ms' }}>
            <CardContent className="p-4 space-y-4">
              {item.room && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <MapPin className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Room</p>
                    <p className="font-medium">{item.room}</p>
                  </div>
                </div>
              )}

              {item.category && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Package className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Category</p>
                    <p className="font-medium">{item.category}</p>
                  </div>
                </div>
              )}

              {item.weight && (
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-warning/10 flex items-center justify-center">
                    <Weight className="h-5 w-5 text-warning" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Weight</p>
                    <p className="font-medium">{item.weight} lbs</p>
                  </div>
                </div>
              )}

              {item.fragile && (
                <Badge variant="destructive" className="mt-2">Fragile Item</Badge>
              )}

              {/* Packed Toggle */}
              <div className="flex items-center justify-between py-3 border-t">
                <Label htmlFor="packed-toggle" className="cursor-pointer font-medium">
                  Packed Status
                </Label>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">
                    {item.packed ? 'Packed' : 'Not Packed'}
                  </span>
                  <Switch
                    id="packed-toggle"
                    checked={item.packed || false}
                    onCheckedChange={togglePacked}
                  />
                </div>
              </div>

              {notes && (
                <div className="pt-3 border-t">
                  <p className="text-xs text-muted-foreground mb-1">Notes</p>
                  <p className="text-sm">{notes}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* QR Code */}
          <Card className="shadow-soft animate-fade-in" style={{ animationDelay: '100ms' }}>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">QR Code</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div id="qr-code-print" className="flex justify-center mb-4">
                <QRCodeSVG
                  value={item.qr_code || ''}
                  size={160}
                  level="H"
                  includeMargin
                />
              </div>
              <Button onClick={handlePrint} variant="outline" className="w-full">
                <Printer className="mr-2 h-4 w-4" />
                Print QR Code
              </Button>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex gap-3 animate-fade-in" style={{ animationDelay: '150ms' }}>
            <Button variant="outline" className="flex-1" onClick={() => setIsEditDialogOpen(true)}>
              <Edit className="mr-2 h-4 w-4" />
              Edit
            </Button>
            <Button variant="destructive" onClick={handleDelete}>
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {item && (
        <EditItemDialog
          open={isEditDialogOpen}
          onOpenChange={setIsEditDialogOpen}
          item={item}
          onSuccess={fetchItem}
        />
      )}
    </AppLayout>
  );
}
