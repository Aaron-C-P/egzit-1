import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useUserRole } from '@/hooks/useUserRole';
import { AppLayout } from '@/components/navigation/AppLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowLeft, Plus, Truck, Star, Shield, Edit2, Trash2, 
  Loader2, CheckCircle2, Users, Package, BarChart3, ShieldX,
  ClipboardList, MessageSquare, DollarSign, Calendar, MapPin,
  XCircle, Send, Clock
} from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import SampleMoversImport from '@/components/admin/SampleMoversImport';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { format } from 'date-fns';
import type { Tables } from '@/integrations/supabase/types';

interface MoverForm {
  name: string;
  description: string;
  location: string;
  phone: string;
  email: string;
  website: string;
  min_price: number;
  price_range: string;
  response_time: string;
  available: boolean;
  verified: boolean;
  insured: boolean;
  logo_url: string;
}

type MoveWithProfile = Tables<'moves'> & {
  profiles?: { name?: string | null; email?: string | null } | null;
};

type MoveBookingSummary = {
  quoted_price?: number | null;
  movers?: { name?: string | null } | null;
};

type MoveWithBookings = Tables<'moves'> & {
  bookings?: MoveBookingSummary[] | MoveBookingSummary | null;
};

const initialForm: MoverForm = {
  name: '',
  description: '',
  location: '',
  phone: '',
  email: '',
  website: '',
  min_price: 99,
  price_range: '$$',
  response_time: '< 2 hours',
  available: true,
  verified: false,
  insured: false,
  logo_url: '',
};

export default function Admin() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { isAdmin, isLoading: roleLoading } = useUserRole();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingMover, setEditingMover] = useState<string | null>(null);
  const [form, setForm] = useState<MoverForm>(initialForm);
  const [services, setServices] = useState<string>('');
  const [activeTab, setActiveTab] = useState('movers');
  const [selectedMove, setSelectedMove] = useState<string | null>(null);
  const [quotePrice, setQuotePrice] = useState<number>(0);
  const [quoteNotes, setQuoteNotes] = useState<string>('');
  const [selectedMoverId, setSelectedMoverId] = useState<string>('');

  // Fetch movers
  const { data: movers = [], isLoading } = useQuery({
    queryKey: ['admin-movers'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('movers')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data || [];
    },
    enabled: isAdmin,
  });

  // Fetch stats
  const { data: stats } = useQuery({
    queryKey: ['admin-stats'],
    queryFn: async () => {
      const [movesRes, usersRes, bookingsRes, pendingMovesRes] = await Promise.all([
        supabase.from('moves').select('id', { count: 'exact' }),
        supabase.from('profiles').select('id', { count: 'exact' }),
        supabase.from('bookings').select('id', { count: 'exact' }),
        supabase.from('moves').select('id', { count: 'exact' }).eq('status', 'pending'),
      ]);
      return {
        moves: movesRes.count || 0,
        users: usersRes.count || 0,
        bookings: bookingsRes.count || 0,
        movers: movers.length,
        pendingMoves: pendingMovesRes.count || 0,
      };
    },
    enabled: isAdmin,
  });

  // Fetch pending move requests
  const { data: pendingMoves = [], isLoading: movesLoading } = useQuery({
    queryKey: ['admin-pending-moves'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('moves')
        .select('*, profiles(name, email)')
        .eq('status', 'pending')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data || [];
    },
    enabled: isAdmin,
  });

  // Fetch all moves for review
  const { data: allMoves = [] } = useQuery({
    queryKey: ['admin-all-moves'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('moves')
        .select('*, profiles(name, email), bookings(*, movers(name))')
        .order('created_at', { ascending: false })
        .limit(50);
      if (error) throw error;
      return data || [];
    },
    enabled: isAdmin,
  });

  // Create/Update mover mutation
  const saveMoverMutation = useMutation({
    mutationFn: async (data: { form: MoverForm; id?: string; services: string[] }) => {
      if (data.id) {
        // Update existing mover
        const { error } = await supabase
          .from('movers')
          .update({
            name: data.form.name,
            description: data.form.description,
            location: data.form.location,
            phone: data.form.phone,
            email: data.form.email,
            website: data.form.website,
            min_price: data.form.min_price,
            price_range: data.form.price_range,
            response_time: data.form.response_time,
            available: data.form.available,
            verified: data.form.verified,
            insured: data.form.insured,
            logo_url: data.form.logo_url,
          })
          .eq('id', data.id);
        if (error) throw error;

        // Update services
        await supabase.from('mover_services').delete().eq('mover_id', data.id);
        if (data.services.length > 0) {
          await supabase.from('mover_services').insert(
            data.services.map(service => ({ mover_id: data.id, service }))
          );
        }
      } else {
        // Create new mover
        const { data: newMover, error } = await supabase
          .from('movers')
          .insert({
            name: data.form.name,
            description: data.form.description,
            location: data.form.location,
            phone: data.form.phone,
            email: data.form.email,
            website: data.form.website,
            min_price: data.form.min_price,
            price_range: data.form.price_range,
            response_time: data.form.response_time,
            available: data.form.available,
            verified: data.form.verified,
            insured: data.form.insured,
            logo_url: data.form.logo_url,
            rating: 0,
            review_count: 0,
          })
          .select()
          .single();
        if (error) throw error;

        // Add services
        if (data.services.length > 0 && newMover) {
          await supabase.from('mover_services').insert(
            data.services.map(service => ({ mover_id: newMover.id, service }))
          );
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-movers'] });
      toast.success(editingMover ? 'Mover updated successfully' : 'Mover added successfully');
      handleCloseDialog();
    },
    onError: (error) => {
      console.error('Error saving mover:', error);
      toast.error('Failed to save mover');
    },
  });

  // Delete mover mutation
  const deleteMoverMutation = useMutation({
    mutationFn: async (id: string) => {
      await supabase.from('mover_services').delete().eq('mover_id', id);
      await supabase.from('mover_reviews').delete().eq('mover_id', id);
      const { error } = await supabase.from('movers').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-movers'] });
      toast.success('Mover deleted successfully');
    },
    onError: (error) => {
      console.error('Error deleting mover:', error);
      toast.error('Failed to delete mover');
    },
  });

  const handleOpenDialog = async (moverId?: string) => {
    if (moverId) {
      const mover = movers.find(m => m.id === moverId);
      if (mover) {
        setForm({
          name: mover.name,
          description: mover.description || '',
          location: mover.location || '',
          phone: mover.phone || '',
          email: mover.email || '',
          website: mover.website || '',
          min_price: mover.min_price || 99,
          price_range: mover.price_range || '$$',
          response_time: mover.response_time || '< 2 hours',
          available: mover.available ?? true,
          verified: mover.verified ?? false,
          insured: mover.insured ?? false,
          logo_url: mover.logo_url || '',
        });
        // Fetch services
        const { data: servicesData } = await supabase
          .from('mover_services')
          .select('service')
          .eq('mover_id', moverId);
        setServices(servicesData?.map(s => s.service).join(', ') || '');
        setEditingMover(moverId);
      }
    } else {
      setForm(initialForm);
      setServices('');
      setEditingMover(null);
    }
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setEditingMover(null);
    setForm(initialForm);
    setServices('');
  };

  const handleSave = () => {
    if (!form.name.trim()) {
      toast.error('Please enter a mover name');
      return;
    }
    const servicesList = services.split(',').map(s => s.trim()).filter(Boolean);
    saveMoverMutation.mutate({ form, id: editingMover || undefined, services: servicesList });
  };

  // Approve move request
  const approveMoveMutation = useMutation({
    mutationFn: async (moveId: string) => {
      const { data: before } = await supabase
        .from('moves')
        .select('status')
        .eq('id', moveId)
        .maybeSingle();
      const { error } = await supabase
        .from('moves')
        .update({ status: 'approved' })
        .eq('id', moveId);
      if (error) throw error;
      await supabase.from('audit_logs').insert({
        move_id: moveId,
        admin_id: (await supabase.auth.getUser()).data.user?.id || null,
        action: 'approved',
        from_status: before?.status || null,
        to_status: 'approved'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-pending-moves'] });
      queryClient.invalidateQueries({ queryKey: ['admin-all-moves'] });
      queryClient.invalidateQueries({ queryKey: ['my-moves'] });
      toast.success('Move request approved');
    },
    onError: () => {
      toast.error('Failed to approve move request');
    },
  });

  // Generate and send quote
  const sendQuoteMutation = useMutation({
    mutationFn: async ({ moveId, moverId, price, notes }: { moveId: string; moverId: string; price: number; notes: string }) => {
      // Create or update booking with quote
      const { data: existingBooking } = await supabase
        .from('bookings')
        .select('id')
        .eq('move_id', moveId)
        .maybeSingle();

      if (existingBooking) {
        const { error } = await supabase
          .from('bookings')
          .update({
            mover_id: moverId,
            quoted_price: price,
            notes: notes || null,
            status: 'confirmed',
          })
          .eq('id', existingBooking.id);
        if (error) throw error;
      } else {
        const { data: move } = await supabase
          .from('moves')
          .select('user_id')
          .eq('id', moveId)
          .single();

        if (!move) throw new Error('Move not found');

        const { error } = await supabase
          .from('bookings')
          .insert({
            user_id: move.user_id,
            move_id: moveId,
            mover_id: moverId,
            quoted_price: price,
            notes: notes || null,
            status: 'confirmed',
          });
        if (error) throw error;
      }

      // Update move status to approved
      const { data: beforeMove } = await supabase
        .from('moves')
        .select('status')
        .eq('id', moveId)
        .maybeSingle();
      const { error: moveError } = await supabase
        .from('moves')
        .update({ status: 'approved' })
        .eq('id', moveId);
      if (moveError) throw moveError;
      await supabase.from('audit_logs').insert({
        move_id: moveId,
        admin_id: (await supabase.auth.getUser()).data.user?.id || null,
        action: 'quote_sent',
        from_status: beforeMove?.status || null,
        to_status: 'approved',
        notes: { mover_id: moverId, quoted_price: price, notes: notes || null }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-pending-moves'] });
      queryClient.invalidateQueries({ queryKey: ['admin-all-moves'] });
      queryClient.invalidateQueries({ queryKey: ['my-moves'] });
      setSelectedMove(null);
      setQuotePrice(0);
      setQuoteNotes('');
      setSelectedMoverId('');
      toast.success('Quote sent successfully');
    },
    onError: () => {
      toast.error('Failed to send quote');
    },
  });

  const handleSendQuote = () => {
    if (!selectedMove || !selectedMoverId || quotePrice <= 0) {
      toast.error('Please fill in all required fields');
      return;
    }
    sendQuoteMutation.mutate({
      moveId: selectedMove,
      moverId: selectedMoverId,
      price: quotePrice,
      notes: quoteNotes,
    });
  };

  const handleRejectMove = async (moveId: string) => {
    const { error } = await supabase
      .from('moves')
      .update({ status: 'cancelled', cancellation_reason: 'Rejected by admin' })
      .eq('id', moveId);
    if (error) {
      toast.error('Failed to reject move');
    } else {
      queryClient.invalidateQueries({ queryKey: ['admin-pending-moves'] });
      queryClient.invalidateQueries({ queryKey: ['admin-all-moves'] });
      toast.success('Move request rejected');
    }
  };

  return (
    <AppLayout>
      <div className="min-h-screen">
        {/* Header */}
        <div className="bg-card border-b px-4 pt-4 pb-3 sticky top-0 z-10">
          <div className="max-w-6xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <h1 className="text-xl font-bold">Admin Dashboard</h1>
            </div>
            <div className="flex items-center gap-2">
              <SampleMoversImport />
              <Button onClick={() => handleOpenDialog()}>
                <Plus className="h-4 w-4 mr-2" />
                Add Mover
              </Button>
            </div>
          </div>
        </div>

        <div className="px-4 py-6 max-w-6xl mx-auto space-y-6">
          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Users className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{stats?.users || 0}</p>
                    <p className="text-xs text-muted-foreground">Users</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                    <Truck className="h-5 w-5 text-accent" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{movers.length}</p>
                    <p className="text-xs text-muted-foreground">Movers</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-warning/10 flex items-center justify-center">
                    <Package className="h-5 w-5 text-warning" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{stats?.moves || 0}</p>
                    <p className="text-xs text-muted-foreground">Moves</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <BarChart3 className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{stats?.bookings || 0}</p>
                    <p className="text-xs text-muted-foreground">Bookings</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-destructive/10 flex items-center justify-center">
                    <ClipboardList className="h-5 w-5 text-destructive" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{stats?.pendingMoves || 0}</p>
                    <p className="text-xs text-muted-foreground">Pending</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="movers">Manage Movers</TabsTrigger>
              <TabsTrigger value="moves">
                Move Requests
                {stats?.pendingMoves ? (
                  <Badge variant="destructive" className="ml-2">{stats.pendingMoves}</Badge>
                ) : null}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="movers" className="space-y-4">
          {/* Movers List */}
          <Card>
            <CardHeader>
              <CardTitle>Manage Movers</CardTitle>
              <CardDescription>Add, edit, or remove moving companies from the marketplace</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : movers.length === 0 ? (
                <div className="text-center py-8">
                  <Truck className="h-12 w-12 mx-auto mb-3 text-muted-foreground" />
                  <p className="text-muted-foreground">No movers added yet</p>
                  <Button onClick={() => handleOpenDialog()} className="mt-4">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Your First Mover
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  {movers.map((mover) => (
                    <div
                      key={mover.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-center gap-4">
                        <img
                          src={mover.logo_url || 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=100&h=100&fit=crop'}
                          alt={mover.name}
                          className="w-12 h-12 rounded-lg object-cover"
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold">{mover.name}</h3>
                            {mover.verified && <Shield className="h-4 w-4 text-accent" />}
                          </div>
                          <div className="flex items-center gap-3 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Star className="h-3 w-3 fill-warning text-warning" />
                              {mover.rating || 0}
                            </span>
                            <span>{mover.location || 'No location'}</span>
                            <Badge variant={mover.available ? 'default' : 'secondary'}>
                              {mover.available ? 'Available' : 'Busy'}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="ghost" size="icon" onClick={() => handleOpenDialog(mover.id)}>
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete Mover</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to delete "{mover.name}"? This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => deleteMoverMutation.mutate(mover.id)}
                                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                              >
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
            </TabsContent>

            <TabsContent value="moves" className="space-y-4">
              {/* Pending Move Requests */}
              <Card>
                <CardHeader>
                  <CardTitle>Pending Move Requests</CardTitle>
                  <CardDescription>Review and approve move requests, generate quotes, and assign movers</CardDescription>
                </CardHeader>
                <CardContent>
                  {movesLoading ? (
                    <div className="flex justify-center py-8">
                      <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    </div>
                  ) : pendingMoves.length === 0 ? (
                    <div className="text-center py-8">
                      <ClipboardList className="h-12 w-12 mx-auto mb-3 text-muted-foreground" />
                      <p className="text-muted-foreground">No pending move requests</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {pendingMoves.map((move: MoveWithProfile) => (
                        <Card key={move.id} className="border-l-4 border-l-warning">
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between">
                              <div className="flex-1 space-y-2">
                                <div className="flex items-center gap-2">
                                  <h3 className="font-semibold">{move.name}</h3>
                                  <Badge variant="outline">Pending</Badge>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm text-muted-foreground">
                                  <div className="flex items-center gap-2">
                                    <MapPin className="h-4 w-4" />
                                    <span className="truncate">{move.pickup_address}</span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <MapPin className="h-4 w-4 text-accent" />
                                    <span className="truncate">{move.delivery_address}</span>
                                  </div>
                                  {move.move_date && (
                                    <div className="flex items-center gap-2">
                                      <Calendar className="h-4 w-4" />
                                      <span>{format(new Date(move.move_date), 'PPP')}</span>
                                    </div>
                                  )}
                                  <div className="flex items-center gap-2">
                                    <Users className="h-4 w-4" />
                                    <span>{move.profiles?.name || 'Unknown User'}</span>
                                  </div>
                                </div>
                                {move.created_at && (
                                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                    <Clock className="h-3 w-3" />
                                    <span>Requested {format(new Date(move.created_at), 'PPP p')}</span>
                                  </div>
                                )}
                              </div>
                              <div className="flex flex-col gap-2 ml-4">
                                <Button
                                  size="sm"
                                  onClick={() => {
                                    setSelectedMove(move.id);
                                    setQuotePrice(move.move_date ? 200 : 150);
                                  }}
                                >
                                  <DollarSign className="h-4 w-4 mr-2" />
                                  Generate Quote
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => navigate(`/chat/${move.user_id}`)}
                                >
                                  <MessageSquare className="h-4 w-4 mr-2" />
                                  Chat
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => approveMoveMutation.mutate(move.id)}
                                >
                                  <CheckCircle2 className="h-4 w-4 mr-2" />
                                  Approve
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="text-destructive hover:text-destructive"
                                  onClick={() => handleRejectMove(move.id)}
                                >
                                  <XCircle className="h-4 w-4 mr-2" />
                                  Reject
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* All Moves */}
              <Card>
                <CardHeader>
                  <CardTitle>All Moves</CardTitle>
                  <CardDescription>View and manage all move requests</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {allMoves.slice(0, 10).map((move: MoveWithBookings) => {
                      const booking = Array.isArray(move.bookings) ? move.bookings[0] : move.bookings;
                      return (
                        <div
                          key={move.id}
                          className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors"
                        >
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <span className="font-medium">{move.name}</span>
                              <Badge variant={
                                move.status === 'completed' ? 'default' :
                                move.status === 'in_progress' ? 'secondary' :
                                move.status === 'approved' ? 'outline' :
                                move.status === 'pending' ? 'destructive' : 'outline'
                              }>
                                {move.status || 'pending'}
                              </Badge>
                              {booking?.movers?.name && (
                                <Badge variant="outline">{booking.movers.name}</Badge>
                              )}
                            </div>
                            <div className="text-sm text-muted-foreground mt-1">
                              {move.pickup_address} → {move.delivery_address}
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            {booking?.quoted_price && (
                              <span className="text-sm font-medium">${booking.quoted_price}</span>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => navigate(`/track/${move.id}`)}
                            >
                              View
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Quote Generation Dialog */}
        <Dialog open={!!selectedMove} onOpenChange={(open) => !open && setSelectedMove(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Generate Quote</DialogTitle>
              <DialogDescription>
                Create a quote for this move request and assign a mover
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Select Mover *</Label>
                <Select value={selectedMoverId} onValueChange={setSelectedMoverId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a mover" />
                  </SelectTrigger>
                  <SelectContent>
                    {movers.filter(m => m.available).map((mover) => (
                      <SelectItem key={mover.id} value={mover.id}>
                        {mover.name} - {mover.location || 'No location'}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Quote Price ($) *</Label>
                <Input
                  type="number"
                  value={quotePrice || ''}
                  onChange={(e) => setQuotePrice(parseInt(e.target.value) || 0)}
                  placeholder="Enter quote amount"
                />
              </div>
              <div className="space-y-2">
                <Label>Notes (optional)</Label>
                <Textarea
                  value={quoteNotes}
                  onChange={(e) => setQuoteNotes(e.target.value)}
                  placeholder="Additional notes for the customer..."
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setSelectedMove(null)}>
                Cancel
              </Button>
              <Button onClick={handleSendQuote} disabled={sendQuoteMutation.isPending}>
                {sendQuoteMutation.isPending ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Send className="h-4 w-4 mr-2" />
                )}
                Send Quote
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Add/Edit Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingMover ? 'Edit Mover' : 'Add New Mover'}</DialogTitle>
              <DialogDescription>
                {editingMover ? 'Update mover details' : 'Add a new moving company to the marketplace'}
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
              <div className="space-y-2">
                <Label>Company Name *</Label>
                <Input
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="ABC Moving Co."
                />
              </div>
              <div className="space-y-2">
                <Label>Location</Label>
                <Input
                  value={form.location}
                  onChange={(e) => setForm({ ...form, location: e.target.value })}
                  placeholder="New York, NY"
                />
              </div>
              <div className="space-y-2">
                <Label>Phone</Label>
                <Input
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  placeholder="+1 (555) 123-4567"
                />
              </div>
              <div className="space-y-2">
                <Label>Email</Label>
                <Input
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="contact@company.com"
                />
              </div>
              <div className="space-y-2">
                <Label>Website</Label>
                <Input
                  value={form.website}
                  onChange={(e) => setForm({ ...form, website: e.target.value })}
                  placeholder="https://www.example.com"
                />
              </div>
              <div className="space-y-2">
                <Label>Logo URL</Label>
                <Input
                  value={form.logo_url}
                  onChange={(e) => setForm({ ...form, logo_url: e.target.value })}
                  placeholder="https://..."
                />
              </div>
              <div className="space-y-2">
                <Label>Min Price ($)</Label>
                <Input
                  type="number"
                  value={form.min_price}
                  onChange={(e) => setForm({ ...form, min_price: parseInt(e.target.value) || 0 })}
                />
              </div>
              <div className="space-y-2">
                <Label>Price Range</Label>
                <Input
                  value={form.price_range}
                  onChange={(e) => setForm({ ...form, price_range: e.target.value })}
                  placeholder="$, $$, $$$"
                />
              </div>
              <div className="space-y-2">
                <Label>Response Time</Label>
                <Input
                  value={form.response_time}
                  onChange={(e) => setForm({ ...form, response_time: e.target.value })}
                  placeholder="< 2 hours"
                />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label>Services (comma-separated)</Label>
                <Input
                  value={services}
                  onChange={(e) => setServices(e.target.value)}
                  placeholder="Local Moving, Long Distance, Packing, Storage"
                />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label>Description</Label>
                <Textarea
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  placeholder="Company description..."
                  rows={3}
                />
              </div>
              <div className="flex items-center justify-between border rounded-lg p-3">
                <Label>Available</Label>
                <Switch
                  checked={form.available}
                  onCheckedChange={(checked) => setForm({ ...form, available: checked })}
                />
              </div>
              <div className="flex items-center justify-between border rounded-lg p-3">
                <Label>Verified</Label>
                <Switch
                  checked={form.verified}
                  onCheckedChange={(checked) => setForm({ ...form, verified: checked })}
                />
              </div>
              <div className="flex items-center justify-between border rounded-lg p-3">
                <Label>Insured</Label>
                <Switch
                  checked={form.insured}
                  onCheckedChange={(checked) => setForm({ ...form, insured: checked })}
                />
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={handleCloseDialog}>
                Cancel
              </Button>
              <Button onClick={handleSave} disabled={saveMoverMutation.isPending}>
                {saveMoverMutation.isPending ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <CheckCircle2 className="h-4 w-4 mr-2" />
                )}
                {editingMover ? 'Save Changes' : 'Add Mover'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AppLayout>
  );
}
