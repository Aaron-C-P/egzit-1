import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { AppLayout } from '@/components/navigation/AppLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  ArrowLeft, MapPin, Truck, Package, Clock, 
  CheckCircle2, Circle, Phone, MessageSquare, Navigation, Play, Flag, Calendar as CalendarIcon
} from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { format } from 'date-fns';
import RouteMap from '@/components/route/RouteMap';
import { calculateDistance, estimateTravelTime, formatTravelTime } from '@/lib/jamaica-locations';
import { Calendar } from '@/components/ui/calendar';
import type { Tables } from '@/integrations/supabase/types';

type Stage = 'pending' | 'approved' | 'scheduled' | 'in_progress' | 'completed';
type MoveRow = Tables<'moves'>;
type BookingRow = Tables<'bookings'>;
type MoveWithBookings = MoveRow & { bookings?: BookingRow[] };

export default function Track() {
  const { moveId } = useParams<{ moveId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [progress, setProgress] = useState(0);
  const [pickupCoords, setPickupCoords] = useState<[number, number] | undefined>();
  const [deliveryCoords, setDeliveryCoords] = useState<[number, number] | undefined>();
  const [routeGeometry, setRouteGeometry] = useState<[number, number][]>([]);
  const [expectedMinutes, setExpectedMinutes] = useState<number | null>(null);
  const [etaText, setEtaText] = useState<string | null>(null);
  const [actualSpeedKmh, setActualSpeedKmh] = useState<number | null>(null);
  const [isTracking, setIsTracking] = useState(false);
  const [startTime, setStartTime] = useState<number | null>(null);
  const [scheduleDate, setScheduleDate] = useState<Date | undefined>();
  const lastInsertRef = useRef<number>(0);
  const lastEtaRef = useRef<number | null>(null);

  // Fetch move details
  const { data: move, isLoading } = useQuery<MoveWithBookings | null>({
    queryKey: ['track-move', moveId],
    queryFn: async (): Promise<MoveWithBookings | null> => {
      const { data, error } = await supabase
        .from('moves')
        .select('*, bookings(*)')
        .eq('id', moveId)
        .eq('user_id', user?.id)
        .maybeSingle();
      if (error) throw error;
      return data as MoveWithBookings | null;
    },
    enabled: !!moveId && !!user,
  });

  const booking = Array.isArray(move?.bookings) ? move?.bookings?.[0] : undefined;
  const stage: Stage = (() => {
    if (!move) return 'pending';
    if (move.status === 'completed') return 'completed';
    if (move.status === 'in_progress') return 'in_progress';
    if (move.status === 'approved' || booking?.status === 'confirmed') {
      if (booking?.scheduled_date) return 'scheduled';
      return 'approved';
    }
    if (move.status === 'pending') return 'pending';
    return 'pending';
  })();

  useEffect(() => {
    if (!isTracking || !deliveryCoords) return;
    let lastPos: GeolocationPosition | null = null;
    const watchId = navigator.geolocation.watchPosition(
      async (pos) => {
        const now = Date.now();
        if (lastPos) {
          const dtHours = (now - lastPos.timestamp) / 3600000;
          const dKm = calculateDistance(
            lastPos.coords.latitude,
            lastPos.coords.longitude,
            pos.coords.latitude,
            pos.coords.longitude
          );
          const speed = dKm / Math.max(dtHours, 1e-6);
          setActualSpeedKmh(Math.max(0, Math.round(speed)));
          const remainingKm = calculateDistance(
            pos.coords.latitude,
            pos.coords.longitude,
            deliveryCoords[0],
            deliveryCoords[1]
          );
          const baselineSpeed = expectedMinutes ? (remainingKm / (expectedMinutes / 60)) : 40;
          const effSpeed = speed > 1 ? speed : baselineSpeed;
          const remainingMinutes = Math.round((remainingKm / effSpeed) * 60);
          const eta = new Date(now + remainingMinutes * 60000);
          setEtaText(format(eta, 'p'));
          if (lastEtaRef.current && eta.getTime() - lastEtaRef.current > 15 * 60000) {
            try {
              await supabase
                .from('audit_logs')
                .insert({
                  move_id: moveId!,
                  user_id: user?.id || null,
                  action: 'eta_delay',
                  notes: { eta: eta.toISOString(), delay_minutes: Math.round((eta.getTime() - lastEtaRef.current) / 60000) }
                });
            } catch {}
          }
          lastEtaRef.current = eta.getTime();
          const totalDistanceKm = routeGeometry.length
            ? calculateDistance(deliveryCoords[0], deliveryCoords[1], pickupCoords?.[0] || deliveryCoords[0], pickupCoords?.[1] || deliveryCoords[1])
            : remainingKm + (pickupCoords ? calculateDistance(pickupCoords[0], pickupCoords[1], deliveryCoords[0], deliveryCoords[1]) : remainingKm);
          const elapsedMinutes = startTime ? Math.round((now - startTime) / 60000) : 0;
          const pct = Math.min(100, Math.max(0, Math.round(((elapsedMinutes) / Math.max(expectedMinutes || 1, 1)) * 100)));
          setProgress(pct);
          if (user?.id && moveId && now - (lastInsertRef.current || 0) > 10000) {
            lastInsertRef.current = now;
            try {
              await supabase
                .from('move_tracking')
                .insert({ move_id: moveId, user_id: user.id, lat: pos.coords.latitude, lon: pos.coords.longitude, speed_kmh: Math.round(speed) });
            } catch {}
          }
        } else {
          setStartTime(now);
        }
        lastPos = pos;
      },
      (error) => {
        console.error('Geolocation error:', error);
      },
      { enableHighAccuracy: true, maximumAge: 10000, timeout: 20000 }
    );

    return () => navigator.geolocation.clearWatch(watchId);
  }, [isTracking, deliveryCoords, expectedMinutes, routeGeometry, pickupCoords, startTime, moveId, user?.id]);

  useEffect(() => {
    if (!move?.pickup_address || !move?.delivery_address) return;
    if (stage !== 'scheduled' && stage !== 'in_progress') return;
    const fetchCoords = async () => {
      const a = await fetch(`https://api.geoapify.com/v1/geocode/search?text=${encodeURIComponent(move.pickup_address!)}&filter=countrycode:jm&limit=1&apiKey=49e9fbc8a11c471fb702b1d0b6b537d3`);
      const ad = await a.json();
      const b = await fetch(`https://api.geoapify.com/v1/geocode/search?text=${encodeURIComponent(move.delivery_address!)}&filter=countrycode:jm&limit=1&apiKey=49e9fbc8a11c471fb702b1d0b6b537d3`);
      const bd = await b.json();
      const pc = ad.features?.[0]?.properties ? [ad.features[0].properties.lat as number, ad.features[0].properties.lon as number] as [number, number] : undefined;
      const dc = bd.features?.[0]?.properties ? [bd.features[0].properties.lat as number, bd.features[0].properties.lon as number] as [number, number] : undefined;
      if (pc) setPickupCoords(pc);
      if (dc) setDeliveryCoords(dc);
    };
    fetchCoords();
  }, [move?.pickup_address, move?.delivery_address, stage]);

  useEffect(() => {
    const run = async () => {
      if (!pickupCoords || !deliveryCoords) return;
      const { data, error } = await supabase.functions.invoke('route-optimizer', {
        body: { pickup: pickupCoords, delivery: deliveryCoords, vehicleType: 'truck' }
      });
      if (error || data?.error) return;
      const primary = data.primary;
      setRouteGeometry(primary.geometry || []);
      const minutes = Math.round((primary.duration || estimateTravelTime(calculateDistance(pickupCoords[0], pickupCoords[1], deliveryCoords[0], deliveryCoords[1]))) / 60);
      setExpectedMinutes(minutes);
      const eta = new Date(Date.now() + minutes * 60000);
      setEtaText(format(eta, 'p'));
    };
    run();
  }, [pickupCoords, deliveryCoords]);

  const scheduleMove = async () => {
    if (!user || !move || !scheduleDate) return;
    const { data: bookingRow } = await supabase
      .from('bookings')
      .select('*')
      .eq('move_id', move.id)
      .maybeSingle();
    if (bookingRow) {
      await supabase.from('bookings').update({ scheduled_date: scheduleDate.toISOString(), status: 'in_progress' }).eq('id', bookingRow.id);
    } else {
      await supabase.from('bookings').insert({
        user_id: user.id,
        move_id: move.id,
        status: 'confirmed',
        scheduled_date: scheduleDate.toISOString(),
      });
    }
  };

  const startMove = async () => {
    if (!move) return;
    await supabase.from('moves').update({ status: 'in_progress' }).eq('id', move.id);
    await supabase.from('audit_logs').insert({
      move_id: move.id,
      user_id: user?.id,
      action: 'start_move',
      from_status: 'approved',
      to_status: 'in_progress'
    });
    setIsTracking(true);
    setStartTime(Date.now());
  };

  const completeMove = async () => {
    if (!move) return;
    const end = Date.now();
    const durationMinutes = startTime ? Math.round((end - startTime) / 60000) : null;
    const perf = { durationMinutes, avgSpeedKmh: actualSpeedKmh, expectedMinutes, timestamp: new Date().toISOString() };
    if (booking?.id) {
      const notes = JSON.stringify({ performance: perf });
      await supabase.from('bookings').update({ status: 'completed', notes }).eq('id', booking.id);
    }
    await supabase.from('moves').update({ status: 'completed' }).eq('id', move.id);
    await supabase.from('move_performance').insert({
      move_id: move.id,
      booking_id: booking?.id || null,
      duration_minutes: perf.durationMinutes || null,
      expected_minutes: perf.expectedMinutes || null,
      avg_speed_kmh: perf.avgSpeedKmh || null,
      delay_minutes: perf.durationMinutes && perf.expectedMinutes ? Math.max(0, perf.durationMinutes - perf.expectedMinutes) : null
    });
    await supabase.from('audit_logs').insert({
      move_id: move.id,
      user_id: user?.id,
      action: 'complete_move',
      from_status: 'in_progress',
      to_status: 'completed'
    });
    setIsTracking(false);
  };

  return (
    <AppLayout>
      <div className="min-h-screen">
        {/* Header */}
        <div className="gradient-hero text-primary-foreground px-4 pt-12 pb-6">
          <div className="max-w-3xl mx-auto">
            <div className="flex items-center gap-3 mb-4">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => navigate(-1)}
                className="text-primary-foreground hover:bg-primary-foreground/20"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold">Track Your Move</h1>
                <p className="text-primary-foreground/80">
                  {move?.name || 'Loading...'}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="px-4 -mt-4 max-w-3xl mx-auto space-y-4 pb-6">
          {stage === 'pending' && (
            <Card className="shadow-card">
              <CardContent className="p-5">
                <div className="flex items-center gap-3">
                  <Truck className="h-6 w-6 text-primary" />
                  <div>
                    <h3 className="font-semibold">Awaiting Approval</h3>
                    <p className="text-sm text-muted-foreground">Your request is pending review</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {stage === 'approved' && (
            <Card className="shadow-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-accent" />
                  Move Approved - Quote Received
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {booking?.quoted_price && (
                  <div className="bg-accent/10 rounded-lg p-3 border border-accent/20">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Quote Amount</span>
                      <span className="text-lg font-bold text-accent">${booking.quoted_price}</span>
                    </div>
                    {booking.notes && (
                      <p className="text-xs text-muted-foreground mt-2">{booking.notes}</p>
                    )}
                  </div>
                )}
                <div>
                  <h3 className="text-sm font-medium mb-2">Schedule Your Move</h3>
                  <Calendar
                    mode="single"
                    selected={scheduleDate}
                    onSelect={setScheduleDate}
                    disabled={(date) => date < new Date()}
                  />
                  <Button onClick={scheduleMove} disabled={!scheduleDate} className="w-full mt-3">
                    Confirm Schedule
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {(stage === 'scheduled' || stage === 'in_progress') && (
            <>
              <Card className="shadow-card">
                <CardContent className="p-5">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                        <Truck className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold">{stage === 'in_progress' ? 'In Transit' : 'Scheduled'}</h3>
                        <p className="text-sm text-muted-foreground">
                          {booking?.scheduled_date ? format(new Date(booking.scheduled_date), 'PPP p') : 'Awaiting date'}
                        </p>
                      </div>
                    </div>
                    {stage === 'in_progress' ? (
                      <Badge variant="default">Live</Badge>
                    ) : (
                      <Button onClick={startMove}>
                        <Play className="h-4 w-4 mr-2" />
                        Start Move
                      </Button>
                    )}
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Progress</span>
                      <span className="font-medium">{Math.round(progress)}%</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>
                  <div className="grid grid-cols-2 gap-4 mt-4 pt-4 border-t">
                    <div className="flex items-center gap-2 text-sm">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span>ETA: {etaText || (expectedMinutes ? formatTravelTime(expectedMinutes) : '—')}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Package className="h-4 w-4 text-muted-foreground" />
                      <span>Speed: {actualSpeedKmh ? `${actualSpeedKmh} km/h` : '—'}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <RouteMap
                pickupCoords={pickupCoords}
                deliveryCoords={deliveryCoords}
                routeGeometry={routeGeometry}
                isTracking={isTracking}
              />

              {stage === 'in_progress' && (
                <Button variant="secondary" onClick={completeMove}>
                  <Flag className="h-4 w-4 mr-2" />
                  Mark Arrived
                </Button>
              )}
            </>
          )}

          {(stage === 'scheduled' || stage === 'in_progress') && (
            <Card className="shadow-soft">
              <CardContent className="p-4 space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                    <MapPin className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Pickup</p>
                    <p className="font-medium">{move?.pickup_address}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                    <MapPin className="h-4 w-4 text-accent" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Delivery</p>
                    <p className="font-medium">{move?.delivery_address}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Contact Actions */}
          <div className="grid grid-cols-2 gap-3">
            <Button variant="outline" className="h-auto py-4">
              <Phone className="h-5 w-5 mr-2" />
              Call Driver
            </Button>
            <Button variant="outline" className="h-auto py-4">
              <MessageSquare className="h-5 w-5 mr-2" />
              Message Team
            </Button>
          </div>

        </div>
      </div>
    </AppLayout>
  );
}
