CREATE POLICY "Anon users can view movers" ON public.movers FOR SELECT TO anon USING (true);
CREATE POLICY "Anon users can view mover services" ON public.mover_services FOR SELECT TO anon USING (true);
