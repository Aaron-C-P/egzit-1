CREATE POLICY "Authenticated users can view movers" ON public.movers FOR SELECT TO authenticated USING (true);
