-- Seed sample movers and their services
INSERT INTO public.movers
  (name, description, location, phone, email, website, min_price, price_range, response_time, available, verified, insured, logo_url, rating, review_count)
VALUES
  ('Kingston Movers Co.', 'Full-service urban movers', 'Kingston, JM', '+1-876-555-1111', 'info@kingstonmovers.co', 'https://kingstonmovers.co', 120, '$$', 'Same day', true, true, true, NULL, 4.6, 128),
  ('Montego Bay Logistics', 'Coastal and resort relocations', 'Montego Bay, JM', '+1-876-555-2222', 'book@mobaylogistics.com', 'https://mobaylogistics.com', 150, '$$$', '24 hours', true, true, true, NULL, 4.8, 93),
  ('Spanish Town Haulage', 'Budget-friendly local moves', 'Spanish Town, JM', '+1-876-555-3333', 'support@spanishtownhaulage.com', 'https://spanishtownhaulage.com', 90, '$', '48 hours', true, false, true, NULL, 4.2, 41),
  ('Mandeville Move & Store', 'Moving with short-term storage', 'Mandeville, JM', '+1-876-555-4444', 'hello@mandevillemove.store', 'https://mandevillemove.store', 130, '$$', '24–48 hours', true, true, true, NULL, 4.5, 57),
  ('Portmore Express Movers', 'Express door-to-door service', 'Portmore, JM', '+1-876-555-5555', 'team@portmoreexpress.com', 'https://portmoreexpress.com', 110, '$$', 'Same day', true, true, false, NULL, 4.4, 68);

-- Seed mover services mapped to inserted movers
INSERT INTO public.mover_services (mover_id, service)
SELECT m.id, v.service
FROM public.movers AS m
JOIN (VALUES
  ('Kingston Movers Co.', 'Full-service packing'),
  ('Kingston Movers Co.', 'Local moves'),
  ('Kingston Movers Co.', 'Fragile handling'),
  ('Montego Bay Logistics', 'Long-distance'),
  ('Montego Bay Logistics', 'Resort logistics'),
  ('Spanish Town Haulage', 'Budget moves'),
  ('Spanish Town Haulage', 'Furniture only'),
  ('Mandeville Move & Store', 'Short-term storage'),
  ('Mandeville Move & Store', 'Packing'),
  ('Portmore Express Movers', 'Express delivery'),
  ('Portmore Express Movers', 'Same-day moves')
) AS v(name, service)
  ON v.name = m.name;
