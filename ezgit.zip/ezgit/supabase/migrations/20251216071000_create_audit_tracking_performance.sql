CREATE TABLE IF NOT EXISTS public.audit_logs (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  move_id uuid NOT NULL REFERENCES public.moves(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id),
  admin_id uuid REFERENCES auth.users(id),
  action text NOT NULL,
  from_status text,
  to_status text,
  notes jsonb,
  created_at timestamptz DEFAULT now() NOT NULL
);

CREATE TABLE IF NOT EXISTS public.move_tracking (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  move_id uuid NOT NULL REFERENCES public.moves(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  lat double precision NOT NULL,
  lon double precision NOT NULL,
  speed_kmh double precision,
  created_at timestamptz DEFAULT now() NOT NULL
);

CREATE TABLE IF NOT EXISTS public.move_performance (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  move_id uuid NOT NULL REFERENCES public.moves(id) ON DELETE CASCADE,
  booking_id uuid REFERENCES public.bookings(id) ON DELETE SET NULL,
  duration_minutes integer,
  expected_minutes integer,
  avg_speed_kmh double precision,
  delay_minutes integer,
  created_at timestamptz DEFAULT now() NOT NULL
);

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.move_tracking ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.move_performance ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view audit logs" ON public.audit_logs FOR SELECT USING (public.has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "Users can view own move audit logs" ON public.audit_logs FOR SELECT TO authenticated USING (EXISTS (SELECT 1 FROM public.moves WHERE moves.id = audit_logs.move_id AND moves.user_id = auth.uid()));
CREATE POLICY "Admins can insert audit logs" ON public.audit_logs FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role) OR auth.uid() IS NOT NULL);

CREATE POLICY "Admins can view tracking" ON public.move_tracking FOR SELECT USING (public.has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "Users can view own tracking" ON public.move_tracking FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users can insert tracking" ON public.move_tracking FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view performance" ON public.move_performance FOR SELECT USING (public.has_role(auth.uid(), 'admin'::public.app_role));
CREATE POLICY "Users can view own performance" ON public.move_performance FOR SELECT TO authenticated USING (EXISTS (SELECT 1 FROM public.moves WHERE moves.id = move_performance.move_id AND moves.user_id = auth.uid()));
CREATE POLICY "Admins can insert performance" ON public.move_performance FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role) OR auth.uid() IS NOT NULL);
