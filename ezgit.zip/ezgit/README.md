# Move Management Application

A comprehensive move management solution built with React, Vite, TypeScript, and Supabase. This application handles the full lifecycle of moving operations, from request to completion, including real-time tracking, admin management, and inventory handling.

## Features

-   **Move Lifecycle Management**: 5-stage workflow (Pending -> Approved -> Scheduled -> In Progress -> Completed).
-   **Admin Dashboard**: Manage moves, approve requests, assign movers, and view audit logs.
-   **Real-time Tracking**: Live GPS tracking of moves with speed monitoring and route visualization.
-   **Inventory Management**: QR code scanning for items, bulk import, and detailed inventory lists.
-   **User Roles**: Separate interfaces for Customers, Movers, and Admins.
-   **Audit Logging**: comprehensive tracking of all system actions and state changes.

## Prerequisites

Before you begin, ensure you have the following installed:
-   [Node.js](https://nodejs.org/) (v18 or higher)
-   [npm](https://www.npmjs.com/) (usually comes with Node.js)

## Getting Started

### 1. Clone the Repository

```bash
git clone <repository_url>
cd app-craft-dawn-29-main
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Environment Configuration

Create a `.env` file in the root directory (or use the existing one) and configure your Supabase credentials. You can copy the example file:

```bash
cp .env.example .env
```

Edit `.env` and add your keys:

```env
VITE_SUPABASE_URL="your_supabase_url"
VITE_SUPABASE_PUBLISHABLE_KEY="your_supabase_anon_key"
```

### 4. Database Setup (Supabase)

This project uses Supabase for the backend. You need to apply the migrations to set up the database schema.

1.  Link your local project to your Supabase project (if using Supabase CLI):
    ```bash
    npx supabase link --project-ref your-project-ref
    ```
2.  Push migrations:
    ```bash
    npx supabase db push
    ```
3.  (Optional) Seed sample data:
    The project includes a seed file for sample movers (`supabase/migrations/20251216062000_seed_sample_movers.sql`). You can run this in the Supabase SQL editor to populate initial data.

### 5. Deploy Edge Functions (Optional)

If you are using features like payment processing or route optimization that rely on Supabase Edge Functions, deploy them using:

```bash
npx supabase functions deploy
```

### 6. Running the Application

Start the development server:

```bash
npm run dev
```

The application will be available at `http://localhost:8080`.

## User Guide

### Customer Flow
1.  **Sign Up/Login**: Create an account to request a move.
2.  **Request Move**: Fill out the move details (pickup/dropoff, inventory).
3.  **Track Status**: Monitor the move status from "Pending" to "Completed".
4.  **Live Tracking**: Once "In Progress", track the mover's location in real-time.

### Admin Flow
1.  **Access Admin Panel**: Navigate to `/admin` (requires admin role).
2.  **Manage Moves**: View all moves, approve requests, and assign movers.
3.  **Audit Logs**: View detailed logs of all system activities.
4.  **Movers Management**: Add or edit mover profiles.

## Technologies Used

-   **Frontend**: React, Vite, TypeScript, Tailwind CSS, shadcn/ui
-   **Backend**: Supabase (PostgreSQL, Auth, Realtime, Edge Functions)
-   **Maps**: Leaflet (via `react-leaflet`)
-   **State Management**: React Query, React Context
